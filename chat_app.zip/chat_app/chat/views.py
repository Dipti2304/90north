from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.contrib.auth import login, authenticate
from .models import Message

def signup_view(request):
    # Handle user registration
    pass

def login_view(request):
    # Handle user login
    pass

@login_required
def chat_view(request):
    users = User.objects.exclude(id=request.user.id)
    return render(request, 'chat/chat.html', {'users': users})

@login_required
def messages_view(request, recipient_id):
    recipient = User.objects.get(id=recipient_id)
    messages = Message.objects.filter(sender=request.user, recipient=recipient) | Message.objects.filter(sender=recipient, recipient=request.user)
    return render(request, 'chat/messages.html', {'messages': messages, 'recipient': recipient})
